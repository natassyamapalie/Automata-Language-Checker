<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Natassya Mapalie (211011060048)</title>
    <style>
      *{
        margin:0px;
        padding:0px;
        box-sizing:border-box;
      }
      .section{
        width: 100%;
        min-height: 80vh;
      }
      .section .container{
        width: 100%;
        display: block;
        margin:auto;
        padding-top:100px;
      }
      .section .container .content-section{
        float:center;
        width: 100%;
      }
      .section .container .content-section .title h1{
        font-size: 35px;
      }
      form{
        margin-top: 20px;
      }
      .mb-3 img{
        width:80%;
        height:auto;
      }
      .text-center button{
        background-color: darkslateblue;
        color:aliceblue;
      }
    </style>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  </head>
  <body>
    <div class="container-fluid mt-5">
      <?php include('navbar.php'); ?>
      <div class="row justify-content-center">
      <div class="col-md-6">
      <div class="section">
        <div class="container">
            <div class="content-section">
                <div class="title">
                  <h1 class="text-center">NFA Language Checker</h1>
                </div>
                <div class="isi">
                  <form method="POST">
                    <div class="mb-3 text-center">
                      <label>This NFA Checker only accepting language b (a + b) b*</label>
                      <img src="foto/mid6.jpg" style="width:80%; height:auto;">
                      <label for="inputString" class="form-label">Check if the word is accepted:</label>
                      <input type="text" class="form-control" name ="inputString" id="exampleFormControlInput1" placeholder="Input a Word">
                      <?php
                        function isAccepted($input){
                          if (preg_match('/^b(a|b)b*$/',$input)){
                            return true;
                          } else{
                            return false;
                          }
                        }
                        if(isset($_POST['tombol'])){
                          $inputString =$_POST['inputString'];
                          if (empty($inputString)){
                            echo '<div style="text-align:center; color:red;">Please input a word</div>';
                          }
                          else{
                            if(isAccepted($inputString)){
                              echo '<div style="text-align:center; color:green;">"'. $inputString .'" is accepted</div>';
                            }else{
                              echo '<div style="text-align:center; color:red;">"'. $inputString .'" is not accepted</div>';
                            }
                          }

                        }
                      ?>
                    </div>
                    <div class="text-center">
                      <button class="btn" type="submit" name="tombol" value="Submit">Submit</button>
                    </div>
                  </form>
                </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  </body>
</html>