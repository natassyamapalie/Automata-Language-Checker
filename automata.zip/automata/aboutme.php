<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Natassya Mapalie (211011060048)</title>
    <style>
      *{
        margin:0px;
        padding:0px;
        box-sizing:border-box;
      }
      .section{
        width: 100%;
        min-height: 100vh;
      }
      .section .container{
        width: 80%;
        display: block;
        margin:auto;
        padding-top:100px;
      }
      .section .container .content-section{
        float:center;
        width: 100%;
      }
      .section .container .content-section .title h1{
        font-size: 28px;
      }
      .section .container .content-section .content h3{
        margin-top: 10px;
        font-size:16px;
        color:#5d5d5d;
        text-align: center;
      }
      .section .container .content-section .social{
        margin-top: 30px;
        text-align: center;
      }
      .section .container .content-section .social i{
        color:darkslateblue;
        font-size: 30px;
        padding:0px 10px;
      }
    </style>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  </head>
  <body>
  <div class="container-fluid mt-5">
      <?php include('navbar.php'); ?>
      <div class="row justify-content-center">
      <div class="col-md-6">
    <div class="section">
        <div class="container">
            <div class="content-section">
                <div class="title">
                    <h1 class="text-center">ABOUT</h1>
                </div>
                <div class="content">
                    <h3>Natassya Klarissa Ribka Mapalie<br/>211011060048<br/>Information Systems</br>Sam Ratulangi University</h3>
                </div>
                <div class="social">
                    <a href="https://instagram.com/natasyamapalie_?igshid=ZGUzMzM3NWJiOQ=="><i class="fa-brands fa-instagram"></i></a>
                    <a href="https://www.youtube.com/channel/UCVJZusYXtuBHkpqMB9K67VQ"><i class="fa-brands fa-youtube"></i></a>
                    <a href="https://github.com/natassyamapalie"><i class="fa-brands fa-github"></i></i></a>
                </div>
            </div>
        </div>
    </div>

    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe"
      crossorigin="anonymous"
    ></script>